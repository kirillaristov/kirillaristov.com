﻿<?php
//Подключаю БД так, чтобы файл работал и локально и на хостинге
//if (is_file('D:\SAS.Planet\marks.sml')) $_DB = 'D:\SAS.Planet\marks.sml';
//else $_DB = $_SERVER['DOCUMENT_ROOT'].$_SERVER['REQUEST_URI'].'as-the-first-settlers-route.sml';

$_DB = "$_SERVER[DOCUMENT_ROOT]/data/2014+/as-the-first-settlers-route-classifier/as-the-first-settlers-route.sml";

/* --- <POST> --- */
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_COOKIE['ds1489'])) {
	if (in_array($_POST['type'], array('track_title', 'track_descr', 'camp_descr')) && is_numeric($_POST['id'])) {
		$type = $_POST['type'];
		$id = (int)$_POST['id'];
		
		$breaks = array("<br />","<br/>",
					"&lt;br&gt;","&lt;br/&gt;","&lt;br /&gt;",
					"&amp;lt;br&amp;gt;","&amp;lt;br/&amp;gt;","&amp;lt;br /&amp;gt;");
					
		//удалить пробелы в начале и конце
		$content = trim($_POST['content']);
		//удалить последний разрыв
		$content = preg_replace('{<br>$}', '', $content);
		//заменить некорректные разрывы на <br>
		$content = str_replace($breaks, '<br>', $content);
		//удалить новые линии
		$newlines = array("\n","\r","\n\r");
		$content = str_replace($newlines, '', $content);
		
		
		//Замена кавычек
		$content = preg_replace('~"(.*)"~im', "«$1»", $content);
		
		$dom = new DOMDocument();
		$dom->load($_DB);
		$dom->formatOutput = true;
		$dom->preserveWhiteSpace = false;

		$xpath = new DOMXPath($dom);
		$ids = $xpath->query("//*[@id='$id']")->item(0);
		
		//Если запись с заданным ID найдена
		if (count($ids) != 0) {
			//Если редактируется track_title
			if ($type == 'track_title') {
				$ids->removeAttribute('name');
				$ids->setAttribute("name", htmlspecialchars($content, ENT_QUOTES));
				preg_match ('/([0-9]{4}-[0-9]{2}-[0-9]{2})_[0-9]{1}\.\s([0-9]{1,3}\.[0-9]{1,2})\skm\s?(down|up|flat)?\.\s(.+)/', $content, $found);
				$return = $found[4];//title
			}
			//Если редактируется track_descr
			if ($type == 'track_descr') {
				$ids->removeAttribute('descr');
				$ids->setAttribute("descr", htmlspecialchars($content, ENT_QUOTES));
				$return = $content;
			}
			//Если редактируется camp_descr
			if ($type == 'camp_descr') {
				$ids->removeAttribute('descr');
				$ids->setAttribute("descr", htmlspecialchars($content, ENT_QUOTES));
				$return = $content;
			}
					
			$dom->save($_DB);
			
			return print json_encode($return);
		}
	}
}
/* --- </POST> --- */

/* --- <GET> --- */
else { ?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>&laquo;As The First Settlers&raquo; Route Classifier | Kirill Aristov</title>
<meta name="robots" content="index, follow">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<meta name="author" content="Kirill Aristov, http://kirillaristov.com">
<link rel="stylesheet" href="/theme/<?php echo date("YmdHi", filemtime("$_SERVER[DOCUMENT_ROOT]/theme/screen.css")); ?>/screen.css" media="all" />
<style>
body {overflow-x:hidden;color:#000;background-color:#fff;font:13px/18px arial,helvetica,sans-serif;}
h1,h2,h3,p {font-family:georgia;}
td div {min-width:40px;min-height:20px;}
</style>
<?php

/* --- <administration part> --- */
if (isset($_COOKIE['ds1489'])) {
/* --- <administration part> --- */

?>
<script src="/theme/cool-edit/cool-edit.js"></script>
<script>
function save () {
	var collection = document.querySelectorAll('.cool_edit');
	
	//Прогон по всем элементам класса
	for (var i=0; i < collection.length; i++) {
		//При получении фокуса
		collection[i].addEventListener('focus', function(event) {
			var target = event.target;
			//Сохранить изначальный контент
			target.dataset.beforeContentEdit = target.innerHTML.replace(/<br>$/g, '');
								
			//При уходе с редактируемого поля
			target.addEventListener('blur', blurfunction);
			function blurfunction () {
				//console.log('before:', target.dataset.beforeContentEdit, 'after:', target.innerHTML.replace(/<br>$/g, ''));
				//Если контент изменился
				if (target.dataset.beforeContentEdit != target.innerHTML.replace(/<br>$/g, '')) {
					//console.log('new content:', target.innerHTML);
					var content;
					var type = target.dataset.type;
					var id = target.id.replace(type, '');
					//console.log('type', type);
					//console.log('id', id);
					
					if (type == 'track_title') {
						content = target.dataset.prefix + target.innerHTML;
					}
					if (type == 'track_descr') {
						content = target.innerHTML;
					}
					if (type == 'camp_descr') {
						content = target.innerHTML;
					}
					
					//браузер добавляет в конец строки <br>
					content.replace(/<br>$/g,'');
					
					var xhr = new XMLHttpRequest();
					xhr.open('POST', 'index.php', false);				
					xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
					
					xhr.onreadystatechange = function () {
						if (this.readyState == 4) {
							if (this.status === 200) {
								if (this.onreadystatechange) {
									this.onreadystatechange = null;
									//console.log('xhr.readyState', this.readyState);
									console.log(this.status, JSON.parse(this.responseText));
									target.style.backgroundColor = '#a0f2a1';
									target.innerHTML = JSON.parse(this.responseText);
									delete target.dataset.beforeContentEdit;
									setTimeout(function() {
										target.style.backgroundColor = 'transparent';
									}, 1000);
								}
							}
							else {
								console.log('status', this.status);
								target.style.backgroundColor = '#f00';
								setTimeout(function() {
									target.style.backgroundColor = 'transparent';
								}, 1000);
							}
						}
					};
					
					var params = 'type=' + type + '&id=' + id + '&content=' + encodeURIComponent(content);
					xhr.send(params);
					
				}

				//удалить событие после однократного срабатывания
				target.removeEventListener('blur', blurfunction);
			}
		});
	}
}

document.addEventListener("DOMContentLoaded", save);
</script>
<?php
/* --- </administration part> --- */
} 
/* --- </administration part> --- */
?>
</head>

<body>
<h2>&laquo;As The First Settlers&raquo; Route Classifier</h2>
<p>Automatically generated, based on actual kml geo data</p>
<p><a href="/en/my-routes/as-the-first-settlers">Route Description</a></p>

<table id="as-the-first-settlers-route-classifier">

<?php
$temp_output = 'temp-output.txt';

/* --- <если файл временного вывода существует, он старше БД, и нет логина в админку> --- */
if (file_exists($temp_output) && (filemtime($temp_output) > filemtime($_DB)) && !isset($_COOKIE['ds1489'])) {
	readfile($temp_output);
}
/* --- <если файла нет, или БД была обновлена, или залогинен в админку - создать новый файл> --- */
else {
	$tracks_array = array();
	//Подключение БД
	$xml = simplexml_load_file ($_DB);

	/* Выборка нужных полей из БД
	== Лагерь ==
	<ROW id="954" name="2014-09-01. Лагерь" descr="Около ЦБК. Копал тропинку через вал песка. 2014-09-01 16:54:21, 53 m" scale1="11" scale2="32" lonlatarr="ABCuuaP/VcEEQADAX8yWrFrfBEDUekEA" lonL="48.333983" latT="55.838549" LonR="48.333983" LatB="55.838549" color1="-1493172480" color2="-1509949440" visible="TRUE" picname="01-camp.png" categoryid="10"/>
	== Трек ==
	<ROW id="1" name="010.Фрязино - р.Веля" scale1="2" scale2="0" lonlatarr="очень-много-букв-и-цифр" lonL="37.8533291066087" latT="56.43330685313213" LonR="38.11989491749762" LatB="55.9772274070418" color1="-1493237760" color2="0" visible="FALSE" picname="" categoryid="1"/> */

	$tracks = $xml->xpath("//ROW[@picname = ''][@categoryid = '100']");
	$camps = $xml->xpath("//ROW[@picname = '01-camp.png' or @picname = '06-home.png' or @picname = '09-hotel.png' or @picname = 'ground-cabin.png' or @picname = 'ground-camping.png' or @picname = 'ground-flood.png' or @picname = 'zz-lovely-place.png' or @picname = 'ground-solarenergy.png' or @picname = 'ground-village.png'][@categoryid = '101']");

/* --- <Camps> --- */
	foreach ($camps as $item){
		$camp_id = (int)$item->attributes()->id;
		$camp_pic = (string)$item->attributes()->picname;
		$camp_title = preg_replace('/\.$/', '', (string)$item->attributes()->name); //удалить завершающую точку
		$camp_descr = preg_replace('/\.$/', '', (string)$item->attributes()->descr);//удалить завершающую точку
		
		//разъединение названия лагеря на дату и название
		preg_match ('/([0-9]{4}-[0-9]{2}-[0-9]{2})\.\s(.+)/', $camp_title, $found_date_and_title);
		
		//если дата в $found_date_and_title найдена, присвоение, иначе дата пустая
		$camp_date = (array_key_exists(1, $found_date_and_title) ? $found_date_and_title[1] : '');
		
		//если дата была найдена, получение чистого названия лагеря, иначе название пустое
		$camp_title = htmlentities ((array_key_exists(2, $found_date_and_title) ? $found_date_and_title[2] : ''), ENT_QUOTES, "UTF-8");
		
		$camps_array[$camp_date] = array(
			'camp_id' => $camp_id,
			'camp_pic' => $camp_pic,
			'camp_title' => $camp_title,
			'camp_descr' => htmlspecialchars_decode($camp_descr, ENT_QUOTES) //5.4.0 	The constants ENT_HTML401, ENT_XML1, ENT_XHTML and ENT_HTML5 were added.
		);
	}
/* --- </Camps> --- */

/* --- <Tracks> --- */
	$all_distance = 0; //cчётчик всей дистанции
	foreach ($tracks as $item){
		/* --- <Определить цвет трека> --- */
		switch ((int)$item->attributes()->color1) {			
			case '-1493237505':			// фиолетовый = протоки
			$track_color = 'branch';
			break;
			
			case '-16711936':			// ярко-зелёный + тёмно-зелёный = суша
			case '-16744320':
			$track_color = 'green';
			break;
			
			case '-16776961':			// непрозрачный синий + непрозрачный голубой = вода
			case '-5846288':
			$track_color = 'blue';
			break;
			
			case '-1493173264':			// кремовый = ж\д
			$track_color = 'railroad';
			break;
			
			case '-1509883905':			// бирюза = самолёт
			$track_color = 'airplane';
			break;
			
			case '-1493189511':			// коричневый = авто
			$track_color = 'avto';
			break;
			
			case '-256':				// жёлтый = пороги и перекаты
			$track_color = 'yellow';
			break;
			
			default:
			$track_color = 'ccc';
		}
		/* --- </Определить цвет трека> --- */
		
		$track_id			= (int)$item->attributes()->id;
		$track_title_full	= html_entity_decode ((string)$item->attributes()->name, ENT_QUOTES, "UTF-8");

		//Разбить $track_title на дату, километраж и название
		preg_match ('/([0-9]{4}-[0-9]{2}-[0-9]{2})_[0-9]{1}\.\s([0-9]{1,3}\.[0-9]{1,2})\skm\s?(down|up|flat)?\.\s(.+)/', $track_title_full, $found_date_km_direction);
		
		$track_date			= (array_key_exists(1, $found_date_km_direction) ? $found_date_km_direction[1] : '');
		$track_km			= (array_key_exists(2, $found_date_km_direction) ? (float)$found_date_km_direction[2] : '');
		$track_direction	= (array_key_exists(3, $found_date_km_direction) ? $found_date_km_direction[3] : '');
		$track_title		= (array_key_exists(4, $found_date_km_direction) ? $found_date_km_direction[4] : '');
		
		//Префикс = дата + порядковый номер + километраж
		$track_prefix = str_replace ($track_title, '', $track_title_full);
		
		$track_descr = html_entity_decode ((string)$item->attributes()->descr, ENT_QUOTES, "UTF-8");
			
		//Обновить счётчик
		$all_distance += $track_km; 
		
		//Если атрибут km у текущего трека присутствует и не равен нулю,
		//добавить этот трек в формируемый массив
		
		if ($track_km != 0) {
			$tracks_array[] = array(
				"track_id"			=> "$track_id",
				"track_title"		=> "$track_title",
				"track_descr"		=> "$track_descr",
				"track_prefix"		=> "$track_prefix",
				"track_date"		=> "$track_date",
				"track_km"			=> "$track_km",
				"track_direction"	=> "$track_direction",
				"track_color"		=> "$track_color"
			);
		}
	}
/* --- </Tracks> --- */
	
	//Сортировка переданного двумерного ассоциативного массива
	//по указанному столбцу и указанным способом (asc/desc)
	function subval_sort($a,$subkey,$sort) {
		if (count($a) != 0 || (!empty($a))) { 
			foreach($a as $k=>$v) {
				$b[$k] = function_exists('mb_strtolower') ? mb_strtolower($v[$subkey]) : strtolower($v[$subkey]);
			}
			//asc = по возрастанию, asort
			//desc = по убыванию, arsort
			if (isset($sort) && $sort == 'asc') asort($b);
			elseif (isset($sort) && $sort == 'desc') arsort($b);
			else asort($b);
			
			foreach($b as $key=>$val) {
				$c[] = $a[$key];
			}
			return $c;
		}
	}

	//Отсортировать созданный массив треков "сначала молодые"
	$tracks_array_sorted = subval_sort($tracks_array, 'track_prefix', 'desc');

	//Вытащить колонку с датами (начиная с php 5.5.0 доступна ф-я array_column)
	function get_dates ($element) {
		return $element['track_date'];
	}
	//Даты всех треков
	$tracks_dates = array_map("get_dates", $tracks_array_sorted);
	
	//Повторяемость разных дат - дата и количество повторений
	$dates_sorted = array_count_values($tracks_dates);

	//Подготовка HTML
	$output = '';
	
	$skip = 0;
	
	foreach ($tracks_array_sorted as $item){

		$track_date = $item['track_date'];
		$rows_to_collapse = (int)$dates_sorted[$track_date];

		//Если на отрезок пути есть точка с такой же датой
		if (array_key_exists($track_date, $camps_array)) {
			$camp_id	= $camps_array[$track_date]['camp_id'];
			$camp_descr	= $camps_array[$track_date]['camp_descr'];
			$camp_pic	= "<img src=\"/theme/marks/{$camps_array[$track_date]['camp_pic']}\" alt=\"\"> ";
		}
		else {
			$camp_id	= '';
			$camp_descr	= '';
			$camp_pic	= '';
		}
		
		//Если повторяемость даты более одного раза и она ещё не встречалась
		if ($rows_to_collapse > 1 && $skip < 1) {
			if (isset($_COOKIE['ds1489'])) {
				$camp_descr_row = "<td class=\"camp_descr\" rowspan=\"$rows_to_collapse\">$camp_pic<div class=\"cool_edit\" id=\"camp_descr$camp_id\" contenteditable=\"true\" data-type=\"camp_descr\">$camp_descr</div></td>";
			}
			else {
				$camp_descr_row = "<td class=\"camp_descr\" rowspan=\"$rows_to_collapse\">$camp_pic$camp_descr</td>";
			}
			//$track_date = $camp_date
			$camp_date_and_descr_row = "\n<td class=\"camp_date\" rowspan=\"$rows_to_collapse\">$track_date</td>\n$camp_descr_row";
			//Сколько пропустить ячеек с датой
			$skip = $rows_to_collapse;
		}
		//Пропустить поле с датой
		else if ($skip >= 1) {
			$camp_date_and_descr_row = "";
		}
		//Единожды встречающаяся дата
		else {
			if (isset($_COOKIE['ds1489'])) {
				$camp_descr_row = "<td class=\"camp_descr\">$camp_pic<div class=\"cool_edit\" id=\"camp_descr$camp_id\" contenteditable=\"true\" data-type=\"camp_descr\">$camp_descr</div></td>";
			}
			else {
				$camp_descr_row = "<td class=\"camp_descr\">$camp_pic$camp_descr</td>";
			}
			$camp_date_and_descr_row = "\n<td class=\"camp_date\">$track_date</td>\n$camp_descr_row";
		}
		$skip--;
		
		if ($item['track_direction'] != '') {
			$track_direction_pic = "<img src=\"/theme/marks/{$item['track_direction']}.png\" alt=\"\"> ";
		}
		else {
			$track_direction_pic = '';
		}
		
		if (isset($_COOKIE['ds1489'])) {
			$track_title_row = "<td class=\"track_title\">$track_direction_pic<div class=\"cool_edit\" id=\"track_title{$item['track_id']}\" contenteditable=\"true\" data-type=\"track_title\" data-prefix=\"{$item['track_prefix']}\">{$item['track_title']}</div></td>";
			$track_descr_row = "<td class=\"track_descr cool_edit\" id=\"track_descr{$item['track_id']}\" contenteditable=\"true\" data-type=\"track_descr\">{$item['track_descr']}</td>";
		}
		else {
			$track_title_row = "<td class=\"track_title\">$track_direction_pic{$item['track_title']}</td>";
			$track_descr_row = "<td class=\"track_descr\">{$item['track_descr']}</td>";
		}

		$output .= <<<EOT
<tr class="table_row {$item['track_color']}">
<td class="track_direction {$item['track_direction']} color"></td>$camp_date_and_descr_row
$track_title_row
<td class="track_km">{$item['track_km']}</td>
$track_descr_row
</tr>\n\n
EOT;
	}

	//Общая дистанция
	$all_distance = round($all_distance);
	//Количество треков
	$tracks_parts = count($tracks_dates);
	//Количество дней в движении
	$dates_count = count($dates_sorted);
	
	$captions = <<<EOT
<tr class="table_caption">
<td class="track_direction"></td>
<td class="camp_date">$dates_count&nbsp;days<br>in action</td>
<td class="camp_descr"></td>
<td class="track_title">$tracks_parts different parts</td>
<td class="track_km">$all_distance<br>km</td>
<td class="track_descr"></td>
</tr>
EOT;


	$write_out = <<<EOT
$captions

$output$captions
EOT;

	$fp = fopen ($temp_output, 'w+');
	fputs ($fp, $write_out);
	fclose ($fp);
	
	readfile ($temp_output);
}
/* --- </если файла нет или БД была обновлена - создать новый файл> --- */

?>

</table>
</body>
</html><?php } /* --- </GET> --- */ ?>